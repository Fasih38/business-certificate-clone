function toggleMobileMenu(menu) {
    menu.classList.toggle("open");
}
// new nav
