<nav>
    <img
      src="https://www.businesscertificateservices.com/build/assets/logo.d19fa9ed.png"
      alt="Not load"
      class="nav-img"
    />
    <ul class="nav-ul">
      <a href="{{url('/')}}" style="color:#fff;">Home</a>
      <a href="{{url('/florida-certificate-of-status')}}" style="color:#fff;">Certificate of Status</a>
      <a href="{{url('/irs-ein-registration-service')}}" style="color:#fff;">IRS EIN Registration</a>
      <a href="{{url('/about')}}" style="color:#fff;">About</a>
      <a href="{{url('/document')}}" style="color:#fff;">Document Search</a>
      <a href="{{url('/contact')}}" style="color:#fff;">Contact Us</a>
      
        </ul>
        <div id="hamburger-icon" onclick="toggleMobileMenu(this)">
        <div class="bar1"></div>
        <div class="bar2"></div>
        <div class="bar3"></div>
        <ul class="mobile-menu">
        <a href="{{url('/')}}" style="color:#fff;">Home</a>
      <a href="{{url('/florida-certificate-of-status')}}" style="color:#fff;">Certificate of Status</a>
      <a href="{{url('/irs-ein-registration-service')}}" style="color:#fff;">IRS EIN Registration</a>
      <a href="{{url('/about')}}" style="color:#fff;">About</a>
      <a href="{{url('/document')}}" style="color:#fff;">Document Search</a>
      <a href="{{url('/contact')}}" style="color:#fff;">Contact Us</a>
      
      
    </ul>
    </div>
  </nav>
