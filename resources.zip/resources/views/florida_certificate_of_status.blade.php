<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet" />
    <!-- font2 -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap"
        rel="stylesheet" />
    {{-- <link rel="stylesheet" href="{{url('/public/style.css')}}" /> --}}
    <link rel="stylesheet" href="{{ url('/public/style2.css') }}" />
    <link rel="shortcut icon" href="{{ url('/public/fav-icon.png') }}" type="image/x-icon" />
    <title>Businesscertificateservices</title>
    <style>
        @media only screen and (max-width: 1000px) {
            .section-2 {
    padding: 6rem 8rem;
    display: flex;
    flex-direction: column;
    gap: 24px;
    text-align: left;
    position: relative;
}
        }
    </style>
</head>

<body>
    <div class="color-whole">
        <div class="clip-path"></div>
        <header class="container">
            @include('sections.header')
            <div class="header-part-2 header-part-2-col">
                <div class="header-part-2-a">
                    <h1>Florida Certificate of Status</h1>
                    <p>
                        Get your Florida Certificate of Status quickly and conveniently.
                    </p>
                    <button class="header-part-2-a-btn">
                        <span>Click to get your Certificate of Status here</span>
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5"
                            stroke="currentColor" class="size-6">
                            <path stroke-linecap="round" stroke-linejoin="round"
                                d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3" />
                        </svg>
                    </button>
                </div>
                <img src="https://www.businesscertificateservices.com/images/florida_flag.png" alt="Img of lady"
                    class="header-part-2-b-img" />
            </div>
        </header>
    </div>
    <!-- section 2 -->
    <div class="section-2-main-div">
        <div class="container">
            <div class="section-2 section-2-col">
                <h2>
                    <span>Florida Certificate of Status</span>
                </h2>
                <p>
                    A Florida Certificate of Status, also known as a Certificate of Good Standing, is an official
                    document issued by the Florida Secretary of State or Department of State that confirms the existence
                    and compliance of a business entity registered in the state of Florida.
                </p>
                <span style="color:#10b981;font-size:25px;font-weight:bold">Why Your Business Needs It</span>
                <p>Obtaining a Florida Certificate of Status is important for several reasons:</p>
                <ul class="list-disc list-inside mb-6">
                    <li>Compliance Verification: It serves as proof that your business is in good standing with the
                        state authorities and has met all necessary requirements.</li>
                    <li>Legal and Financial Transactions: Many banks, lenders, and investors may require a Certificate
                        of Status before entering into transactions, securing loans, or engaging in business
                        partnerships.</li>
                    <li>Licensing and Permitting: Some licensing agencies or government bodies may ask for a Certificate
                        of Status to ensure your business is eligible for permits, licenses, or contracts.</li>
                    <li>Contractual Obligations: It may be required when bidding for government contracts or when
                        participating in public or private tenders.</li>
                </ul>
                <svg class="fill-slate-300" width="56" height="43">
                    <path
                        d="M4.532 30.45C15.785 23.25 24.457 12.204 29.766.199c.034-.074-.246-.247-.3-.186-4.227 5.033-9.298 9.282-14.372 13.162C10 17.07 4.919 20.61.21 24.639c-1.173 1.005 2.889 6.733 4.322 5.81M18.96 42.198c12.145-4.05 24.12-8.556 36.631-12.365.076-.024.025-.349-.055-.347-6.542.087-13.277.083-19.982.827-6.69.74-13.349 2.24-19.373 5.197-1.53.75 1.252 7.196 2.778 6.688">
                    </path>
                </svg>
            </div>
        </div>
    </div>
    <!-- section3 -->
    <div class="color-whole">
        <div class="clip-path-2"></div>

        <main class="container section-3">
            <h2>Secure Your Business's Future with the Certificate of Status and Tax EIN Number!</h2>
            <div class="section-3-cards-main">
                <!-- sddd -->
                <div class="section-3-cards">
                    <div>
                        <h3>Certificate of Status +
                            EIN Registration Service</h3>
                        <h2 class="price_sec">$85.37</h2>
                        <p style="height:160px;">
                            Instantly secure your business's legitimacy with our hassle-free Certificate of Status PDF
                            delivered straight to your email!
                        </p>
                        <hr>
                        <p>Includes:</p>
                        <ul class="text-slate-500 space-y-3 grow mb-6" style="list-style-type: none;height:350px">
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">PDF of Certificate of Status sent to your
                                    email.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:18px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Delivered within 1 business day from the time of
                                    order receipt.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Secure and Convenient online order option.</span>
                            </li>
                        </ul>
                        <a href="{{ url('/document') }}"
                            style="background-color: #2563eb;padding: 10px 20px;color: #fff;font-size: 16px;text-decoration:none;text-align:center">Click
                            to Start Order -></a>
                    </div>
                </div>
                <div class="section-3-cards">
                    <div>
                        <h3>Certificate of Status +
                            EIN Registration Service</h3>
                        <h2 class="price_sec">$85.37</h2>
                        <p style="height:160px;">
                            Ensure your business's credibility with both an immediate PDF of your Certificate of Status
                            as well as a tangible Certificate of Status hard copy, a tangible testament to your
                            legitimacy and compliance.
                        </p>
                        <hr>
                        <p>Includes:</p>
                        <ul class="text-slate-500 space-y-3 grow mb-6" style="list-style-type: none;height:350px">
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">PDF of Certificate of Status sent to your
                                    email.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:15px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Hard copy of Certificate of Status delivered via
                                    mail.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:40px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Immediate delivery of the PDF email Certificate of
                                    Status. A 3-4 week delivery for the Certified Hard copy from the time of order
                                    receipt.</span></li>

                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Easy and convenient online order options.</span>
                            </li>
                        </ul>
                        <a href="{{ url('/document') }}"
                            style="background-color: #2563eb;padding: 10px 20px;color: #fff;font-size: 16px;text-decoration:none;text-align:center">Click
                            to Start Order -></a>
                    </div>
                </div>
                <!-- sddd -->
                <div class="section-3-cards">
                    <div>
                        <h3>Certificate of Status +
                            EIN Registration Service</h3>
                        <h2 class="price_sec">$85.37</h2>
                        <p style="height:160px;">
                            Get access to banking with your EIN tax identification. Order EIN tax registration service.
                        </p>
                        <hr>
                        <p>Includes:</p>
                        <ul class="text-slate-500 space-y-3 grow mb-6" style="list-style-type: none;height:350px">
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">PDF of Certificate of Status sent to your
                                    email.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:17px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Secure and convenient registration of your Tax EIN
                                    number.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:23px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Delivered within 1-2 business days from the time
                                    of receipt of signed forms.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:12px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Ultra-secure and compliant order form.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:19px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Tax EIN numbers allows you to comply with IRS
                                    requirements.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:18px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">EIN allows legal Compliance and Expansion
                                    Opportunities</span></li>
                        </ul>
                        <a href="{{ url('/document') }}"
                            style="background-color: #2563eb;padding: 10px 20px;color: #fff;font-size: 16px;text-decoration:none;text-align:center">Click
                            to Start Order -></a>
                    </div>
                </div>
                <!-- <div>fasih</div>
                    <div>fasih</div> -->
            </div>
        </main>
    </div>
    <!-- section 4 -->
    <div class="section-2-main-div">
        <div class="container">
            <div class="section-2 section-2-col">
                <h2>
                    <span>Advantages of Having a Certificate of Status</span>
                </h2>
                <p>Here are some advantages of obtaining and maintaining an active Certificate of Status for your
                    Florida business:</p>
                <ul class="list-disc list-inside mb-6">
                    <li>Enhanced Credibility: It demonstrates to clients, partners, and stakeholders that your business
                        is legitimate, compliant, and trustworthy.</li>
                    <li>Expanded Opportunities: Having a Certificate of Status increases your business's eligibility for
                        various financial opportunities, including loans, investments, and government contracts.</li>
                    <li>Smooth Business Operations: It streamlines your ability to engage in legal and financial
                        transactions, avoiding unnecessary delays or obstacles.</li>
                    <li>Good Reputation: Maintaining a current Certificate of Status can help your business build a
                        positive reputation, potentially attracting more customers and business opportunities.</li>
                </ul>
                <svg class="fill-slate-300" width="56" height="43">
                    <path
                        d="M4.532 30.45C15.785 23.25 24.457 12.204 29.766.199c.034-.074-.246-.247-.3-.186-4.227 5.033-9.298 9.282-14.372 13.162C10 17.07 4.919 20.61.21 24.639c-1.173 1.005 2.889 6.733 4.322 5.81M18.96 42.198c12.145-4.05 24.12-8.556 36.631-12.365.076-.024.025-.349-.055-.347-6.542.087-13.277.083-19.982.827-6.69.74-13.349 2.24-19.373 5.197-1.53.75 1.252 7.196 2.778 6.688">
                    </path>
                </svg>
                <p>Remember, the specific process and requirements for obtaining a Florida Certificate of Status may vary. It's important to consult the official Florida Secretary of State website or seek professional advice to ensure you fulfill all the necessary steps.</p>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
    </div>
    </header>
    </div>
    </div>
    <!-- sec 5 -->
    <!-- sec-6 -->
    @include('sections.footer')
</body>

</html>
