<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Business Certificate Services</title>
    <link rel="stylesheet" href="{{url('/public/style.css')}}" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&display=swap" rel="stylesheet">
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
        }

        .container {
            max-width: 100%;
            margin: 0 auto;
            padding: 20px;
        }

        .header {
            /* background-color: #1c2b48; */
            padding: 0px 20px;
            text-align: center;
            color: white;
        }

        .header h1 {
            margin: 0;
            font-size: 70px;
            font-family: "Playfair Display", serif;
            padding: 0px 120px;
            line-height: 1;
        }

        .image-section {
            text-align: center;
            margin: 20px 0;
        }

        .image-section img {
            width: 100%;
            max-width: 1000px;
            height: auto;
            border-radius: 10px;
            margin-top: 80px
        }

        .content {
            /* background-color: white; */
            padding: 20px;
            border-radius: 10px;
            /* box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); */
        }

        .content h2 {
            color: #1c2b48;
            font-size: 38px;
            font-family: "Playfair Display", serif;
        }

        .content p {
            line-height: 1.6;
            color: #64748b;
            font-size: 19px;
        }

        .content ul {
            list-style-type: none;
            padding: 0;
        }

        .content li {
            margin: 10px 0;
            color: #64748b;
            font-size: 19px;
            line-height: 1.8;
        }

        .content li strong {
            color: #1c2b48;
        }
        .clip-path {
            content: " ";
            height: 500px;
            width: 100%;
            background-color: #0f172a;
            position: absolute;
            z-index: -111;
            clip-path: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
        }
        .container_new{
            width: 60%;
            margin: 0px auto;
            padding: 0px 100px
        }
        .footer-1{
            margin-top: 100px;
        }
        @media only screen and (max-width: 900px) {
            .header h1{
                margin: 0;
                font-size: 70px;
                font-family: "Playfair Display", serif;
                padding: 0px 40px;
                line-height: 1;
            }
            .container_new {
    width: 90%;
    margin: 0px auto;
    padding: 0px 40px;
}
        }
        @media only screen and (max-width: 750px) {
            .header h1{
                margin: 0;
                font-size: 50px;
                font-family: "Playfair Display", serif;
                padding: 0px 30px;
                line-height: 1;
            }
            .container_new {
        width: 100%;
        margin: 0px auto;
        padding: 0px 30px;
    }
        }
        @media only screen and (max-width: 550px) {
            .header h1{
                margin: 0;
                font-size: 30px;
                font-family: "Playfair Display", serif;
                padding: 0px 20px;
                line-height: 1;
            }
        }
    </style>
</head>
<body>
    <div class="">
        <div class="color-whole">
            <div class="clip-path"></div>
            <header class="container">
                @include('sections.header')
            </header>
        </div>
        <div class="header container">
            <h1>Business Certificate Services</h1>
        </div>
        <div class="image-section">
            <img src="https://www.businesscertificateservices.com/images/about-intro.jpg" alt="Team Image">
        </div>
        <div class="content container_new">
            <h2>Our Story</h2>
            <p style="margin-top:10px">Welcome to <strong>BusinessCertificateServices.com</strong>! We are your trusted partner when it comes to obtaining Certificate of Statuses for Florida corporations. Our mission is to provide a streamlined and efficient service that allows individuals and businesses to easily acquire the documentation they need to establish their legal standing within the state of Florida.</p> <br>
            <p>At Florida Certificates of Status, we understand the importance of maintaining a current and active status for your corporation. Whether you're a seasoned business owner or just starting out, having a Certificate of Status is crucial for various transactions, including opening bank accounts, securing loans, entering into contracts, or demonstrating compliance with state regulations.</p><br>
            <p>Our team of experienced professionals is dedicated to simplifying the process of obtaining a Certificate of Status. We have in-depth knowledge of the requirements and procedures involved, allowing us to guide you through the application process with ease. With our expertise and attention to detail, we ensure that your Certificate of Status is accurate, up to date, and meets all necessary legal standards.</p><br>
            <p>Why choose Florida Certificates of Status? We pride ourselves on offering a comprehensive and customer-centric service that prioritizes your needs. Here's what sets us apart:</p>
            <ul>
                <li><strong>Easy and Convenient:</strong> We understand that your time is valuable. Our online platform enables you to request a Certificate of Status from the comfort of your home or office, eliminating the need for lengthy visits to government offices or paperwork.</li>
                <li><strong>Fast Turnaround:</strong> We value efficiency. Once we receive your request, our team works diligently to process it promptly. You can expect to receive your Certificate of Status in a timely manner, allowing you to proceed with your business activities without delay.</li>
                <li><strong>Expert Guidance:</strong> Navigating the bureaucratic landscape can be overwhelming. Our knowledgeable team is here to support you every step of the way. Should you have any questions or require assistance, we are just a phone call or email away.</li>
                <li><strong>Accuracy and Compliance:</strong> We take great care in ensuring the accuracy and compliance of your Certificate of Status. Our meticulous approach minimizes the risk of errors or omissions, providing you with the peace of mind that your documentation is reliable and legally sound.</li>
                <li><strong>Transparent Pricing:</strong> Our pricing structure is transparent and upfront. We offer competitive rates for our services, and you will never encounter any hidden fees or surprises. What you see is what you get.</li>
            </ul>
            <p>At Florida Certificates of Status, we are committed to your satisfaction. We strive to exceed your expectations by delivering a seamless experience that saves you time and effort. Let us handle the complexities of obtaining your Certificate of Status so that you can focus on what you do best – running your business.</p>
            <p>Thank you for choosing Florida Certificates of Status. We look forward to serving you and helping you achieve your business goals in the state of Florida.</p>
        </div>
    </div>
    @include('sections.footer')

</body>
</html>
