<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="{{ url('/public/style.css') }}" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&display=swap" rel="stylesheet">

    <style>
        .title{
            font-family: "Playfair Display", serif;
            color: #1e293b !important;
            font-size: 36px;
            margin-bottom: 30px;
        }
        .clip-path {
            content: " ";
            height: 100%;
            width: 100%;
            background-color: #0f172a;
            position: absolute;
            z-index: -111;
            clip-path: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
        }
        #content {
            padding-top: 50px;
            text-align: left;
            max-width: 730px;
            margin: 0 auto;
        }

        h2 {
            color: #2ecc71;
        }

        #contact-info h3 {
            margin-top: 40px;
            color: #707070;
            font-size: 20px;
        }

        #contact-info p {
            margin: 15px 0;
            color: #707070;
            font-size: 16px;
        }
        body{
            font-size: 14px !important;
        }
        .paragraph{
            line-height: 2.75rem;
    font-weight: 300;
    font-size: 2rem;
    font-family: sans-serif;
    color: #707070;
    margin-top: 20px;
        }
        .strong{
            font-size: 20px
        }
        .footer-1{
            margin-top: 100px;
        }
        @media only screen and (max-width: 900px) {
            .container {
    width: 100% !important;
    margin: 0 auto;
}
#content {
    padding-top: 50px;
    text-align: left;
    max-width: 730px;
    margin: 0 auto;
    padding: 50px 50px;
}
        }
    </style>
</head>

<body>
    <div class="color-whole">
        <div class="clip-path"></div>
        <header class="container">
            @include('sections.header')
        </header>
    </div>
    <div id="content">
        <h2 class="title">Terms of Service</h2>
        <h2>Introduction</h2>
        <p class="paragraph">These terms of service ("Terms") govern your use of the BusinessCertificateServices.com website ("Website") and the services provided by the company Business Certificate Services Florida ("Company"). By using the Website and availing the Company's services, you agree to comply with these Terms. If you do not agree with any part of these Terms, please refrain from using the Website and its services.</p><br>
        <h2>Service Description</h2>
        <p class="paragraph">The Company provides certificates of status for Florida Companies. These certificates confirm the legal existence and good standing of a company registered in the state of Florida. The Company retrieves and the records from the Florida Department of State and provides these documents for its customers.</p><br>
        <h2>Account Creation</h2>
        <p class="paragraph">In order to access and use certain features of the Website and request certificates of status, you may need to create an account. You are responsible for maintaining the confidentiality of your account credentials and for any activity that occurs under your account. You agree to provide accurate, current, and complete information during the registration process. The Company reserves the right to suspend or terminate your account if any information provided is found to be inaccurate, false, or misleading.</p><br>
        <h2>Payment</h2>
        <p class="paragraph">The Company charges a fee for its certificate of status services. Payment for the requested services must be made through the available payment methods provided on the Website. You agree to pay all fees and charges associated with your use of the Company's services. The Company reserves the right to modify its fees and payment methods at any time and will provide notice of any changes on the Website.</p><br>
        <h2>Intellectual Property</h2>
        <p class="paragraph">The content on the Website, including but not limited to text, graphics, logos, images, and software, is protected by intellectual property laws. You may not reproduce, distribute, modify, transmit, or use the content of the Website without the Company's prior written consent.</p><br>
        <h2>Disclaimer of Liability</h2>
        <p class="paragraph">The Company strives to provide accurate and reliable information, but the Website and its services are provided on an "as is" and "as available" basis without any warranties or representations. The Company does not guarantee the accuracy, completeness, or timeliness of the information provided. You agree that your use of the Website and its services is at your own risk. The Company shall not be liable for any direct, indirect, incidental, consequential, or punitive damages arising out of or in connection with your use of the Website or its services.</p><br>
        <h2>Indemnification</h2>
        <p class="paragraph">You agree to indemnify and hold the Company harmless from any claims, damages, losses, liabilities, and expenses (including legal fees) arising out of or in connection with your use of the Website or any violation of these Terms.</p><br>
        <h2>Termination</h2>
        <p class="paragraph">The Company reserves the right to terminate or suspend your access to the Website and its services at any time, with or without cause or notice.</p><br>
    </div>
    @include('sections.footer')
</body>

</html>
