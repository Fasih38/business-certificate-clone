<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap" rel="stylesheet" />
    <!-- font2 -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap"
        rel="stylesheet" />
    {{-- <link rel="stylesheet" href="{{url('/public/style.css')}}" /> --}}
    <link rel="stylesheet" href="{{ url('/public/style2.css') }}" />
    <link rel="shortcut icon" href="{{ url('/public/fav-icon.png') }}" type="image/x-icon" />
    <title>Businesscertificateservices</title>
    <style>
        .clip-path-2 {
    content: " ";
    height: 1000px;
    width: 100%;
    background-color: #0f172a;
    position: absolute;
    z-index: -111;
    clip-path: polygon(0 0, 100% 0%, 100% 100%, 0 100%);
}
.clip-path {
    content: " ";
    height: 100%;
    width: 100%;
    background-color: #0f172a;
    position: absolute;
    z-index: -111;
    clip-path: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
}
    </style>
</head>

<body>
    <div class="color-whole">
        <div class="clip-path"></div>
        <header class="container">
            @include('sections.header')

        </header>
    </div>
    <!-- section 2 -->
    <!-- section3 -->
    <div class="color-whole">
        <div class="clip-path-2"></div>

            <main class="container section-3">
                <h2>Secure Your Business's Future with the Certificate of Status and Tax EIN Number!</h2>
                <div class="section-3-cards-main">
                    <!-- sddd -->
                    <div class="section-3-cards">
                        <div>
                            <h3>Certificate of Status +
                                EIN Registration Service</h3>
                            <h2 class="price_sec">$85.37</h2>
                            <p style="height:160px;">
                                Instantly secure your business's legitimacy with our hassle-free Certificate of Status PDF
                                delivered straight to your email!
                            </p>
                            <hr>
                            <p>Includes:</p>
                            <ul class="text-slate-500 space-y-3 grow mb-6" style="list-style-type: none;height:350px">
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:13px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">PDF of Certificate of Status sent to your
                                        email.</span></li>
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:18px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">Delivered within 1 business day from the time of
                                        order receipt.</span></li>
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:13px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">Secure and Convenient online order option.</span>
                                </li>
                            </ul>
                            <a href="{{ url('/document') }}"
                                style="background-color: #2563eb;padding: 10px 20px;color: #fff;font-size: 16px;text-decoration:none;text-align:center">Click
                                to Start Order -></a>
                        </div>
                    </div>
                    <div class="section-3-cards">
                        <div>
                            <h3>Certificate of Status +
                                EIN Registration Service</h3>
                            <h2 class="price_sec">$85.37</h2>
                            <p style="height:160px;">
                                Ensure your business's credibility with both an immediate PDF of your Certificate of Status
                                as well as a tangible Certificate of Status hard copy, a tangible testament to your
                                legitimacy and compliance.
                            </p>
                            <hr>
                            <p>Includes:</p>
                            <ul class="text-slate-500 space-y-3 grow mb-6" style="list-style-type: none;height:350px">
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:13px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">PDF of Certificate of Status sent to your
                                        email.</span></li>
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:15px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">Hard copy of Certificate of Status delivered via
                                        mail.</span></li>
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:40px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">Immediate delivery of the PDF email Certificate of
                                        Status. A 3-4 week delivery for the Certified Hard copy from the time of order
                                        receipt.</span></li>

                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:13px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">Easy and convenient online order options.</span>
                                </li>
                            </ul>
                            <a href="{{ url('/document') }}"
                                style="background-color: #2563eb;padding: 10px 20px;color: #fff;font-size: 16px;text-decoration:none;text-align:center">Click
                                to Start Order -></a>
                        </div>
                    </div>
                    <!-- sddd -->
                    <div class="section-3-cards">
                        <div>
                            <h3>Certificate of Status +
                                EIN Registration Service</h3>
                            <h2 class="price_sec">$85.37</h2>
                            <p style="height:160px;">
                                Get access to banking with your EIN tax identification. Order EIN tax registration service.
                            </p>
                            <hr>
                            <p>Includes:</p>
                            <ul class="text-slate-500 space-y-3 grow mb-6" style="list-style-type: none;height:350px">
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:13px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">PDF of Certificate of Status sent to your
                                        email.</span></li>
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:17px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">Secure and convenient registration of your Tax EIN
                                        number.</span></li>
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:23px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">Delivered within 1-2 business days from the time
                                        of receipt of signed forms.</span></li>
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:12px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">Ultra-secure and compliant order form.</span></li>
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:19px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">Tax EIN numbers allows you to comply with IRS
                                        requirements.</span></li>
                                <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                        class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                        xmlns="http://www.w3.org/2000/svg"
                                        style="fill: #10b981;height:18px;margin:0px 10px">
                                        <path
                                            d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                        </path>
                                    </svg><span style="font-size: 14px;">EIN allows legal Compliance and Expansion
                                        Opportunities</span></li>
                            </ul>
                            <a href="{{ url('/document') }}"
                                style="background-color: #2563eb;padding: 10px 20px;color: #fff;font-size: 16px;text-decoration:none;text-align:center">Click
                                to Start Order -></a>
                        </div>
                    </div>
                    <!-- <div>fasih</div>
                        <div>fasih</div> -->
                </div>
            </main>
        </div>
        <div class="color-whole">
            <div class="clip-path-2"></div>
        <main class="container section-3">
            <h2>EIN Application Service
                Get Access to Banking Services and IRS Compliance</h2>
            <div class="section-3-cards-main" style="justify-content: center !important">
                <!-- sddd -->
                {{-- <div class="section-3-cards">
                    <div>
                        <h3>Certificate of Status +
                            EIN Registration Service</h3>
                        <h2 class="price_sec">$85.37</h2>
                        <p style="height:160px;">
                            Instantly secure your business's legitimacy with our hassle-free Certificate of Status PDF
                            delivered straight to your email!
                        </p>
                        <hr>
                        <p>Includes:</p>
                        <ul class="text-slate-500 space-y-3 grow mb-6" style="list-style-type: none;height:350px">
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">PDF of Certificate of Status sent to your
                                    email.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:18px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Delivered within 1 business day from the time of
                                    order receipt.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Secure and Convenient online order option.</span>
                            </li>
                        </ul>
                        <a href="{{ url('/document') }}"
                            style="background-color: #2563eb;padding: 10px 20px;color: #fff;font-size: 16px;text-decoration:none;text-align:center">Click
                            to Start Order -></a>
                    </div>
                </div> --}}

                <div class="section-3-cards" style="width:50%;">
                    <div>
                        <h3>EIN Application Service
                            Employer Identification Number</h3>
                        <h2 class="price_sec">$
                            135
                            .50</h2>
                        <p style="height:160px;">
                            Your new business needs an EIN number to comply with banking requirements. We offer a full
                            service Employer Identification Number (EIN) Application Service with the IRS.
                        </p>
                        <hr>
                        <p>Includes:</p>
                        <ul class="text-slate-500 space-y-3 grow mb-6" style="list-style-type: none;height:380px !important;line-height:1.5">
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Full Service EIN Application Service.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">100% Money back Guarantee that you will receive your EIN number.</span>
                            </li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:30px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Fast Delivery: We process the application within 1 business day of receiving the signed documents that we provide. Expected turn around within 4 business days.</span>
                            </li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Constant updates on the status on your EIN application.</span>
                            </li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:30px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Convenience. We spend time on hold with the IRS so you don't have to. If there is an issue with the IRS, we spend unlimited hours on the phone with them to resolve the issue.</span>
                            </li>
                        </ul>
                        <a href="{{ url('/document') }}"
                            style="background-color: #2563eb;padding: 10px 20px;color: #fff;font-size: 16px;text-decoration:none;text-align:center">Click
                            to Start Order -></a>
                    </div>
                </div>
                <!-- sddd -->
                <div class="section-3-cards" style="width:50%;">
                    <div>
                        <h3>EIN Application Service +
                            PDF Email of Certificate of Status</h3>
                        <h2 class="price_sec">$
                            200
                            87</h2>
                        <p style="height:160px;">
                            Your new business needs an EIN number to comply with banking requirements. Get access to banking with our EIN application service and obtain a PDF of your Certificate of Status.
                        </p>
                        <hr>
                        <p>Includes:</p>
                        <ul class="text-slate-500 space-y-3 grow mb-6" style="list-style-type: none;height:380px !important;line-height:1.5">
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Full Service EIN Application Service.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">PDF of the Certificate of Status send via Email within 1 business day.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">100% Money back Guarantee that you will receive your EIN number.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:30px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Fast Delivery: We process the application within 1 business day of receiving the signed documents that we provide. Expected turn around within 4 business days.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:13px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Constant updates on the status on your EIN application.</span></li>
                            <li class="flex items-center" style="display: flex;margin: 20px 0px;"><svg
                                    class="w-3 h-3 fill-current text-emerald-500 mr-3 shrink-0" viewBox="0 0 12 12"
                                    xmlns="http://www.w3.org/2000/svg"
                                    style="fill: #10b981;height:30px;margin:0px 10px">
                                    <path
                                        d="M10.28 2.28L3.989 8.575 1.695 6.28A1 1 0 00.28 7.695l3 3a1 1 0 001.414 0l7-7A1 1 0 0010.28 2.28z">
                                    </path>
                                </svg><span style="font-size: 14px;">Convenience. We spend time on hold with the IRS so you don't have to. If there is an issue with the IRS, we spend unlimited hours on the phone with them to resolve the issue.</span></li>
                        </ul>
                        <a href="{{ url('/document') }}"
                            style="background-color: #2563eb;padding: 10px 20px;color: #fff;font-size: 16px;text-decoration:none;text-align:center">Click
                            to Start Order -></a>
                    </div>
                </div>
                <!-- <div>fasih</div>
                    <div>fasih</div> -->
            </div>
        </main>
    </div>
    </div>
    </div>
    </div>
    </div>
    </header>
    </div>
    </div>
    <!-- sec 5 -->
    <!-- sec-6 -->
    @include('sections.footer')
</body>

</html>
