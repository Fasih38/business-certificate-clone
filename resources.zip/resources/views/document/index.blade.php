<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Certificate of Status</title>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&family=Roboto:wght@400;500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="{{url('/public/style.css')}}" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&display=swap" rel="stylesheet">
    <style>
        body
        {
            font-size: 18px !important;
        }

        .font_custom{
            font-family: "Playfair Display", serif;
            font-optical-sizing: auto;
            font-weight: 700;
            font-style: normal;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding-top: 0px !important;
            text-align: center;
        }

        .step-bar {
            display: flex;
            justify-content: space-between;
            border:1px solid #ddd;
        }

        .step {
            flex: 1;
            text-align: center;
            position: relative;
            padding: 10px;
            display: flex;
            justify-content: space-around;
        }

        /* .step::before {
        content: "";
        width: 100%;
        height: 4px;
        background-color: #e0e0e0;
        position: absolute;
        top: 50%;
        left: 0;
        z-index: -1;
        } */

        .step.active::before,
        .step.active::after {
            background-color: #0062cc;
        }

        .step span {
            background-color: #fff;
            padding: 24px 20px;
            border-radius: 50%;
            border: 2px solid #e0e0e0;
            position: relative;
            z-index: 1;
            display: flex;
            align-items: center;
            height: 30px;
        }

        .step.active span {
            border-color: #0062cc;
        }
        .step.active{
            border-bottom: 4px solid #3c99f5;
        }
        .step.active span {
            color: #0062cc;
            font-weight: bold;
            color: #0062cc;
            font-weight: bold;
            display: flex;
            align-items: center;
            height: 30px;
        }

        .step:nth-child(1)::before {
            display: none;
        }

        .step p {
            font-family: 'Roboto', sans-serif;
            color: #555;
            margin-top: 10px;
        }

        .content {
            /* background-color: #eaf0f9; */
            padding: 50px;
            border-radius: 8px;
            color: #1e293b;
            /* box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); */
        }

        .content h1 {
            font-size: 2em;
            color: #333;
            margin-bottom: 20px;
        }

        .content p {
            font-size: 1.2em;
            color: #666;
            margin-bottom: 30px;
        }

        .search-box {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .search-box input {
            padding: 10px;
            border: 2px solid #e0e0e0;
            border-radius: 5px 0 0 5px !important;
            outline: none;
            flex: 1;
            height: 50px;
            width: 300px
        }

        .search-box button {
            padding: 10px 20px;
            border: 2px solid #0062cc;
            background-color: #0062cc;
            color: #fff;
            border-radius: 0 5px 5px 0 !important;
            cursor: pointer;
            height: 48px;
        }

        .search-box button:hover {
            background-color: #004d99;
            border-color: #004d99;
        }
        .d-none{
            display: none;
        }
        .clip-path {
            content: " ";
            height: 100%;
            width: 100%;
            background-color: #0f172a;
            position: absolute;
            z-index: -111;
            clip-path: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
        }
        .active_step{
            color: #0062cc !important;
        }
        .footer-1{
            padding-top: 100px !important;
        }
        @media only screen and (max-width: 1000px) {

            .display-none{
                display: none;
            }
            .step{
                justify-content: space-between;

            }
            .step span{
                z-index: 0;
            }
            .nav-img{
                z-index: 11111111111111111
            }
            .step{
                justify-content: start;
            }
            .font_custom{
                font-size: 4rem !important;
            }
        }
        @media only screen and (min-width: 1000px) {
            .font_custom{
                font-size: 5rem !important;
            }
        }
        @media only screen and (max-width: 750px) {
            .container{
                width: 100% !important;
            }
        }
        @media only screen and (max-width: 600px) {
            .font_custom{
                font-size: 3rem !important;
            }
            .content p {
                font-size: .9em;
                color: #666;
                margin-bottom: 30px;
            }

        }
        @media only screen and (max-width: 550px) {
            .search-box input {
                padding: 10px;
                border: 2px solid #e0e0e0;
                border-radius: 5px 0 0 5px !important;
                outline: none;
                flex: 1;
                height: 50px;
                width: 270px;
            }
            .search-box button {
                padding: 10px 10px;
                border: 2px solid #0062cc;
                background-color: #0062cc;
                color: #fff;
                border-radius: 0 5px 5px 0 !important;
                cursor: pointer;
                height: 48px;
            }
            .content {
                /* background-color: #eaf0f9; */
                padding: 30px;
                border-radius: 8px;
                color: #1e293b;
                /* box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); */
            }
        }
        @media only screen and (max-width: 440px) {
            .content {
                /* background-color: #eaf0f9; */
                padding: 30px;
                border-radius: 8px;
                color: #1e293b;
                /* box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); */
            }
            .search-box input {
                padding: 10px;
                border: 2px solid #e0e0e0;
                border-radius: 5px 0 0 5px !important;
                outline: none;
                flex: 1;
                height: 50px;
                width: 220px;
            }
        }
    </style>
</head>
<body>
    <div class="color-whole">
        <div class="clip-path"></div>
        <header class="container">
            @include('sections.header')
        </header>
    </div>
    <div class="" style="margin-top:0px">
        <div class="step-bar container" >
            <div class="step active">
                <span>1</span>
                <div><p class="active_step">Enter Company Information</p> <p>the Company Document Number</p></div>
            </div>
            <svg style="height: 80px" class=" display-none h-full w-full text-gray-300" viewBox="0 0 12 82" fill="none" preserveAspectRatio="none"><path d="M0.5 0V31L10.5 41L0.5 51V82" stroke="currentcolor" vector-effect="non-scaling-stroke"></path></svg>
            <div class="step">
                <span>2</span>
                <p>Order Documents<br>Select the Order Options</p>
            </div>
            <svg style="height: 80px" class="display-none h-full w-full text-gray-300" viewBox="0 0 12 82" fill="none" preserveAspectRatio="none"><path d="M0.5 0V31L10.5 41L0.5 51V82" stroke="currentcolor" vector-effect="non-scaling-stroke"></path></svg>
            <div class="step">
                <span>3</span>
                <p>Submit Order<br>Submit the Order For Processing</p>
            </div>
        </div>
        @if (!Session::has('message'))
        <div class="content content_section " style="background-color: #f1f5f9;width:100% !important">
            <div class="container">
                <h1 class="font_custom" style="" >Search for your Company and <br> order your <span style="color: #0062cc;">Certificate of Status</span>.</h1>
                <p>Enter your company name or document number. Then select your company to start your order. Your Certificate of Status will be processed and sent to your email within 24 hours.</p>
                <div class="search-box">
                    <form action="{{url('/document/get_detail')}}" method="POST">
                        @csrf
                        <input type="text" name="document_number" placeholder="Document Number or Company Name">
                        <button type="submit">Search Now</button>
                    </form>
                </div>
            </div>
        </div>
        @endif
    </div>
    @include('document.detail_table')
    @include('sections.footer')
</body>
</html>
