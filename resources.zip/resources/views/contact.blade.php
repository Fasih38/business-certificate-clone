<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="{{ url('/public/style.css') }}" />

    <style>
        .clip-path {
            content: " ";
            height: 100%;
            width: 100%;
            background-color: #0f172a;
            position: absolute;
            z-index: -111;
            clip-path: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
        }
        #content {
            padding-top: 50px;
            text-align: left;
            max-width: 730px;
            margin: 0 auto;
        }

        h2 {
            color: #2ecc71;
        }

        #contact-info h3 {
            margin-top: 40px;
            color: #707070;
            font-size: 20px;
        }

        #contact-info p {
            margin: 15px 0;
            color: #707070;
            font-size: 16px;
        }
        body{
            font-size: 14px !important;
        }
        .paragraph{
            line-height: 2.75rem;
    font-weight: 300;
    font-size: 2rem;
    font-family: sans-serif;
    color: #707070;
    margin-top: 20px;
        }
        .strong{
            font-size: 20px
        }
        .footer-1{
            margin-top: 100px;
        }
        @media only screen and (max-width: 900px) {
            .container {
    width: 100% !important;
    margin: 0 auto;
}
#content {
    padding-top: 50px;
    text-align: left;
    max-width: 730px;
    margin: 0 auto;
    padding: 50px 50px;
}
        }
    </style>
</head>

<body>
    <div class="color-whole">
        <div class="clip-path"></div>
        <header class="container">
            @include('sections.header')
        </header>
    </div>
    <div id="content">
        <h2>Get in Touch</h2>
        <p class="paragraph">Thank you for your interest in Business Certificate Services. We are here to assist you with any questions or inquiries you may have. Please feel free to reach out to us using the contact details provided below or by filling out the contact form.</p>
        <div id="contact-info">
            <h3>Contact Information</h3>
            <p><strong class="strong">Business Certificate Services Florida</strong></p>
            <p>Orlando, Florida, 32804</p>
            <p>Email: support@businesscertificateservices.com</p>
        </div>
    </div>
    @include('sections.footer')
</body>

</html>
