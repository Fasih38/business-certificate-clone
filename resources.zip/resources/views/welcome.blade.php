<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Inter:wght@100..900&display=swap"
      rel="stylesheet"
    />
    <!-- font2 -->
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link
      href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400..900;1,400..900&display=swap"
      rel="stylesheet"
    />
    <link rel="stylesheet" href="{{url('/public/style.css')}}" />
    <link rel="shortcut icon" href="{{url('/public/fav-icon.png')}}" type="image/x-icon" />
    <title>Businesscertificateservices</title>
  </head>
  <body>
    <div class="color-whole">
      <div class="clip-path"></div>
      <header class="container">
        @include('sections.header')
        <div class="header-part-2 header-part-2-col">
          <div class="header-part-2-a">
            <h1>Florida Business Services</h1>
            <p>
              Simplifying Success, One Form at a Time. Offering Business
              Services and Support since 2022
            </p>
            <button class="header-part-2-a-btn">
              <span>Click to get your Certificate of Status here</span>
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                stroke-width="1.5"
                stroke="currentColor"
                class="size-6"
              >
                <path
                  stroke-linecap="round"
                  stroke-linejoin="round"
                  d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
                />
              </svg>
            </button>
          </div>
          <img
            src="https://www.businesscertificateservices.com/images/woman_at_desk.jpg"
            alt="Img of lady"
            class="header-part-2-b-img"
          />
        </div>
      </header>
    </div>
    <!-- section 2 -->
    <div class="section-2-main-div">
      <div class="container">
        <div class="section-2 section-2-col">
          <h2>
            Secure your business's reputation and credibility with our
            hassle-free
            <span>Certificate of Status</span> service.
          </h2>
          <p>
            Take the next step towards success and ensure your legal standing
            with confidence today! Accelerate your business our streamlined
            Employer Identification Number (EIN) service. Obtain your official
            Employer Identification Number (EIN) effortlessly. Get started now
            and pave the way for financial growth and compliance!
          </p>
          <svg class="fill-slate-300" width="56" height="43">
            <path
              d="M4.532 30.45C15.785 23.25 24.457 12.204 29.766.199c.034-.074-.246-.247-.3-.186-4.227 5.033-9.298 9.282-14.372 13.162C10 17.07 4.919 20.61.21 24.639c-1.173 1.005 2.889 6.733 4.322 5.81M18.96 42.198c12.145-4.05 24.12-8.556 36.631-12.365.076-.024.025-.349-.055-.347-6.542.087-13.277.083-19.982.827-6.69.74-13.349 2.24-19.373 5.197-1.53.75 1.252 7.196 2.778 6.688"
            ></path>
          </svg>
        </div>
      </div>
    </div>
    <!-- section3 -->
    <div class="color-whole">
      <div class="clip-path-2"></div>

      <main class="container section-3">
        <h2>Top Reasons why you should use our services:</h2>
        <div class="section-3-cards-main">
          <!-- sddd -->
          <div class="section-3-cards">
            <img
              src="https://www.businesscertificateservices.com/images/features-home-3-01.jpg"
              alt=""
            />
            <div>
              <h3>Time-saving</h3>
              <p>
                Streamlines the EIN registration and Certificate of Status
                process. Allows you to quickly and efficiently obtain a Employer
                Identification Number without navigating complex IRS procedures.
              </p>
            </div>
            <svg
              class="w-16 h-16 fill-current section-3-box-svg"
              viewBox="0 0 64 64"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                class="text-white"
                d="m30.152 39.848.672-.408C32.24 33.632 33.92 32 35.96 26.768a10.714 10.714 0 0 0-.432-2.28c-.288-.096-.888-.336-1.44-.336-1.776.48-3.48 1.632-5.208 2.088-1.272.336-.576 2.352.36 3.312.672-.384 1.872-1.008 2.28-.96-1.248 2.112-3 6.12-3 7.704 0 .528-.48.816-.48 1.104 0 .288.12.6.144.936.384-.24.48-.12.48.264.264.192.672.504 1.032.816.144-.744.384-1.56.888-1.464l-.6 1.704c.072.072.12.144.168.192Z"
              ></path>
            </svg>
          </div>
          <!-- sddd -->
          <div class="section-3-cards">
            <img
              src="https://www.businesscertificateservices.com/images/features-home-3-02.jpg"
              alt=""
            />
            <div>
              <h3>Time-saving</h3>
              <p>
                Streamlines the EIN registration and Certificate of Status
                process. Allows you to quickly and efficiently obtain a Employer
                Identification Number without navigating complex IRS procedures.
              </p>
            </div>
            <svg
              class="w-16 h-16 fill-current section-3-box-svg"
              viewBox="0 0 64 64"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                class="text-white"
                d="M25.508 39.044c.312 0 .672-.024 1.008-.048-.096-.432.384-.528.816-.096 1.488-.216 3.12-.624 4.416-.888l.6-.624c1.104 0 .456.624 1.44.432.168-1.008.552-.456 1.92-1.176l.072.168c-.264.192-.72.408-1.152.576v.216c1.584-.528 1.848-1.32 2.928-1.464 1.224-.168 2.184-.048 2.52-.792l-1.728-.096-.168-.24h1.008l-.096-.216c-1.032 0-1.44-.168-2.4-.576-2.016.192-5.328.912-7.632.768 1.296-1.512 3.72-2.592 5.712-3.648.024.36-.384.6-.744.816l.072.216 1.344-.744c.048-.72.552-1.344 1.272-1.44.6-.744.864-1.776.864-2.76 0-1.08-1.2-2.208-3.024-2.208l.096-.264c-1.968.192-5.4.36-6.792 1.176-.504.288-.456.696-.792.984.48.36.024.528.504 1.2.624.888.648 1.488 1.152 1.2 1.056-.576 2.4-1.176 3.384-1.176.48 0 .864.168 1.104.504 0 1.488-6.744 3.792-9.288 7.632.48.096.312.48.072.84.504.768.84 1.728 1.512 1.728Zm7.344-5.976.912-.48-.048-.264-.912.6.048.144Zm7.08 3.216-.096-.216-1.128.216c.144.168.72.048 1.224 0Z"
              ></path>
            </svg>
          </div>
          <!-- sddd -->
          <div class="section-3-cards">
            <img
              src="https://www.businesscertificateservices.com/images/features-home-3-03.jpg"
              alt=""
            />
            <div>
              <h3>Time-saving</h3>
              <p>
                Streamlines the EIN registration and Certificate of Status
                process. Allows you to quickly and efficiently obtain a Employer
                Identification Number without navigating complex IRS procedures.
              </p>
            </div>
            <svg
              class="w-16 h-16 fill-current section-3-box-svg"
              viewBox="0 0 64 64"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                class="text-white"
                d="M25.53 40.038c1.607-.216 3.071-.576 4.655-1.08.048-.36.288-.6.552-.624l.12.408a37.15 37.15 0 0 0 2.352-.912l.12.264c1.416-.72 2.64-1.2 3.984-2.376l.312.144c1.392-1.248 1.632-2.904 1.632-4.728-.624-.912-1.416-1.656-2.784-2.112.36-.72.768-1.752.984-2.784-.12-.648-.408-1.224-.864-1.776-.84-.072-2.088-.24-3.264-.24l-.192-.216a18.485 18.485 0 0 0-1.152-.048c-1.776 0-4.056 1.032-4.056 1.944 0 .624.048 1.248.192 1.824l.268-.172c.578-.368 1.127-.671 1.46-.38l-1.656.792c.048.144.12.336.192.48 1.296-.672 3.96-1.608 5.64-1.608-.456.984-2.376 2.496-3.672 2.832l-.24 1.056c.456 1.248.864 1.032 2.16 1.68l.12-.288c1.8.216 3.336 0 3.96.72-.312 1.464-3.984 2.712-5.4 3.12-.504.144-.84.144-.936-.096-1.416.744-3.36.696-5.064.696-.24.768-.336 1.608.048 2.544l.72-.312c.144.288-.432.696-.456.96-.024.24.12.312.264.288Zm7.703-2.352-.144-.264.744-.312.072.216-.672.36Zm-4.344 1.248-.048-.264c.216-.048.384-.096.552-.12a.588.588 0 0 1 .48.12l-.984.264Z"
              ></path>
            </svg>
          </div>
          <!-- <div>fasih</div>
          <div>fasih</div> -->
        </div>
      </main>
    </div>
    <!-- section 4 -->
    <div class="sec-4">
      <div class="color-whole">
        <main class="container section-3">
          <h2 class="color-heading-black">
            Simplifying Success, One Form at a Time
          </h2>
        </main>
        <header class="container">
          <div class="header-part-4">
            <img
              src="{{url('/public/features-home-02.png')}}"
              alt="Img of lady"
              class="header-part-4-a-img"
            />
            <div class="header-part-4-a">
              <h1>Built for New Florida Businesses</h1>
              <p>
                Streamlines the bureaucratic hurdles for Florida businesses,
                offering a hassle-free, efficient platform for obtaining crucial
                documents like EINs and certificates of status.
              </p>
              <div class="main-cards-4">
                <div class="header-part-4-cards">
                  <div class="cards-svg-flex">
                    <svg
                      class="w-4 h-4 fill-current text-blue-600 shrink-0 mt-1 mr-4 svg-sec-4-a"
                      viewBox="0 0 16 16"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M9.4 6.6c.8.8.8 2 0 2.8-.8.8-2 .8-2.8 0-.8-.8-5-7.8-5-7.8s7 4.2 7.8 5Z"
                      ></path>
                      <path
                        d="M8 16c-4.4 0-8-3.6-8-8 0-.6.4-1 1-1s1 .4 1 1c0 3.3 2.7 6 6 6s6-2.7 6-6-2.7-6-6-6c-.6 0-1-.4-1-1s.4-1 1-1c4.4 0 8 3.6 8 8s-3.6 8-8 8Z"
                      ></path>
                    </svg>
                    <div class="svg-sec-4-b">
                      <h3>Centralized Services</h3>

                      <p>
                        Offers a one-stop-shop for various business needs,
                        including EIN registration and obtaining certificates of
                        status. This eliminates the need to navigate to multiple
                        websites or government agencies.
                      </p>
                    </div>
                  </div>
                </div>
                <div class="header-part-4-cards">
                  <div class="cards-svg-flex">
                    <svg
                      class="w-4 h-4 fill-current text-blue-600 shrink-0 mt-1 mr-4 svg-sec-4-a"
                      viewBox="0 0 16 16"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M4.019 15.276.034 1.329A1.058 1.058 0 0 1 1.33.034L15.276 4.02c.896.299.996 1.494.1 1.893L8.8 8.8l-2.79 6.574c-.498.897-1.693.797-1.992-.1ZM2.525 2.525l2.69 9.463 1.892-4.383c.1-.199.299-.398.498-.498l4.383-1.893-9.463-2.69Z"
                      ></path>
                    </svg>
                    <div class="svg-sec-4-b">
                      <h3>User-Friendly Interface</h3>

                      <p>
                        The platform is designed for ease of use, with clear
                        instructions and a straightforward process. This makes
                        it accessible even to those who are not familiar with
                        business registration procedures.
                      </p>
                    </div>
                  </div>
                </div>
                <div class="header-part-4-cards">
                  <div class="cards-svg-flex">
                    <svg
                      class="w-4 h-4 fill-current text-blue-600 shrink-0 mt-1 mr-4 svg-sec-4-a"
                      viewBox="0 0 16 16"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path
                        d="M15.686 5.71 10.291.3c-.4-.4-.999-.4-1.399 0a.97.97 0 0 0 0 1.403l.6.6L2.698 6.01l-1-1.002c-.4-.4-.999-.4-1.398 0a.97.97 0 0 0 0 1.403l1.498 1.502 2.398 2.404L.6 14.023 2 15.425l3.696-3.706 3.997 4.007c.5.5 1.199.2 1.398 0a.97.97 0 0 0 0-1.402l-.999-1.002 3.697-6.711.6.6c.599.602 1.199.201 1.398 0 .3-.4.3-1.1-.1-1.502Zm-7.193 6.11L4.196 7.511l6.695-3.706 1.298 1.302-3.696 6.711Z"
                      ></path>
                    </svg>
                    <div class="svg-sec-4-b">
                      <h3>Expert Support and Guidance</h3>

                      <p>
                        Provides expert support and guidance throughout the
                        process. This is invaluable for new business owners or
                        those unfamiliar with the specifics of business
                        documentation.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </header>
      </div>
    </div>
    <!-- sec 5 -->
    <div class="section-2-main-div sec-5-bgcolor">
      <div class="container">
        <div class="section-2 sec-5 sec-5-col">
          <h2 class="white-5">
            Say goodbye to being on the phone for hours on hold with the IRS.
          </h2>
          <p>
            When there is an issue with your EIN (Employer Identification
            Number) application. Let us take the time and complete this process
            for you. We have done hundreds of EIN applications for our
            customer's new businesses.
          </p>
          <button class="header-part-5-btn">
            <span>Start Your EIN Application Now</span>
            <svg
              xmlns="http://www.w3.org/2000/svg"
              fill="none"
              viewBox="0 0 24 24"
              stroke-width="1.5"
              stroke="currentColor"
              class="size-6"
            >
              <path
                stroke-linecap="round"
                stroke-linejoin="round"
                d="M13.5 4.5 21 12m0 0-7.5 7.5M21 12H3"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
    <!-- sec-6 -->
@include('sections.footer')
  </body>
</html>
