<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <link rel="stylesheet" href="{{ url('/public/style.css') }}" />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,700;1,700&display=swap" rel="stylesheet">

    <style>
        .title{
            font-family: "Playfair Display", serif;
            color: #1e293b !important;
            font-size: 36px;
            margin-bottom: 30px;
        }
        .clip-path {
            content: " ";
            height: 100%;
            width: 100%;
            background-color: #0f172a;
            position: absolute;
            z-index: -111;
            clip-path: polygon(0 0, 100% 0%, 100% 100%, 0% 100%);
        }
        #content {
            padding-top: 50px;
            text-align: left;
            max-width: 730px;
            margin: 0 auto;
        }

        h2 {
            color: #2ecc71;
        }

        #contact-info h3 {
            margin-top: 40px;
            color: #707070;
            font-size: 20px;
        }

        #contact-info p {
            margin: 15px 0;
            color: #707070;
            font-size: 16px;
        }
        body{
            font-size: 14px !important;
        }
        .paragraph{
            line-height: 2.75rem;
    font-weight: 300;
    font-size: 2rem;
    font-family: sans-serif;
    color: #707070;
    margin-top: 20px;
        }
        .strong{
            font-size: 20px
        }
        .footer-1{
            margin-top: 100px;
        }
        @media only screen and (max-width: 900px) {
            .container {
    width: 100% !important;
    margin: 0 auto;
}
#content {
    padding-top: 50px;
    text-align: left;
    max-width: 730px;
    margin: 0 auto;
    padding: 50px 50px;
}
        }
    </style>
</head>

<body>
    <div class="color-whole">
        <div class="clip-path"></div>
        <header class="container">
            @include('sections.header')
        </header>
    </div>
    <div id="content">
        <h2 class="title">Privacy Policy</h2>
        <h2>Introduction</h2>
        <p class="paragraph">This Privacy Policy ("Policy") outlines how BusinessCertificateServices.com ("Company", "we", "us") collects, uses, and protects the personal information of individuals who use our website ("Website") and our services. We are committed to maintaining the privacy and security of your personal information and complying with applicable data protection laws.</p><br>
        <h2>Information We Collect</h2>
        <p class="paragraph">
            When you use our Website and services, we may collect the following types of personal information:
        </p>
        <ul style="padding: 10px 30px;font-size:15px !important">
            <li class="paragraph" style="font-size: 1.7rem !important">Personal identification information (e.g., name, address, email address, phone number).</li>
            <li class="paragraph" style="font-size: 1.7rem !important">Company information (e.g., company name, registration number)</li>
            <li class="paragraph" style="font-size: 1.7rem !important">Payment information (e.g., credit card details, billing address)</li>
        </ul>
        <p class="paragraph" style="">We collect this information when you voluntarily provide it to us or when it is necessary for the performance of our services. We may also collect certain non-personal information, such as IP addresses and browsing data, for analytics and website improvement purposes.</p>
        <br>
        <h2>Use of Information</h2>
        <p class="paragraph" style="">We use the collected information for the following purposes:</p>
        <ul style="padding: 10px 30px;line-height:1;font-size:15px !important">
            <li class="paragraph" style="font-size: 1.7rem !important">To provide and deliver our services, including generating certificates of status</li>
            <li class="paragraph" style="font-size: 1.7rem !important">To process payments and fulfill orders</li>
            <li class="paragraph" style="font-size: 1.7rem !important">To communicate with you regarding your account, orders, and customer support</li>
            <li class="paragraph" style="font-size: 1.7rem !important">To improve and optimize our Website and services</li>
            <li class="paragraph" style="font-size: 1.7rem !important">To comply with legal obligations and enforce our Terms of Service</li>
        </ul>
        <h2>Data Security</h2>
        <p class="paragraph">We implement appropriate technical and organizational measures to protect the personal information we collect and store. However, please note that no method of transmission or storage is completely secure, and we cannot guarantee the absolute security of your data.</p>
        <br>
        <h2>Sharing of Information</h2>
        <p class="paragraph">We may share your personal information with third parties in the following circumstances:</p>
        <ul style="padding: 10px 30px;line-height:1;font-size:15px !important">
            <li class="paragraph" style="font-size: 1.7rem !important">With service providers and business partners who assist us in delivering our services</li>
            <li class="paragraph" style="font-size: 1.7rem !important">With law enforcement or government authorities as required by applicable laws and regulations</li>
            <li class="paragraph" style="font-size: 1.7rem !important">In connection with a merger, acquisition, or sale of all or a portion of our business</li>
            <li class="paragraph" style="font-size: 1.7rem !important">With your consent or as otherwise disclosed at the time of collection</li>
        </ul>
        <p class="paragraph">We do not sell or rent your personal information to third parties for marketing purposes.</p>
        <br>
        <h2>Your Rights</h2>
        <p class="paragraph">You have certain rights regarding your personal information, including:</p>
        <ul style="padding: 10px 30px;line-height:1;font-size:15px !important">
            <li class="paragraph" style="font-size: 1.7rem !important">The right to access, update, or delete your personal information</li>
            <li class="paragraph" style="font-size: 1.7rem !important">The right to withdraw your consent at any time, if applicable</li>
            <li class="paragraph" style="font-size: 1.7rem !important">The right to object to the processing of your personal information</li>
            <li class="paragraph" style="font-size: 1.7rem !important">The right to lodge a complaint with a supervisory authority</li>
        </ul>
        <p class="paragraph">To exercise these rights or if you have any questions or concerns about the processing of your personal information, please contact us using the contact details provided below.</p>
        <br>
        <h2>Changes to this Policy</h2>
        <p class="paragraph">We may update this Privacy Policy from time to time. Any changes will be effective when we post the revised Policy on our Website. We encourage you to review this Policy periodically for any updates or changes.</p>
        <br>
        <h2>Contact Us</h2>
        <p class="paragraph">
            If you have any questions or concerns regarding our refund policy, please don't hesitate to contact us:
        </p>
        <p class="paragraph" style="    margin-top: 17px;">Business Certificate Services Florida</p>
        <p class="paragraph" style="    margin-top: 7px;">Orlando, Florida, 32804</p>
        <p class="paragraph" style="    margin-top: 7px;">Email: support@businesscertificateservices.com</p>
    </div>
    @include('sections.footer')
</body>

</html>
